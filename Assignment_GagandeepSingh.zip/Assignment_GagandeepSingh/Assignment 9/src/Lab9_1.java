import java.util.*;
import java.io.*;

public class Lab9_1{
	public static void main (String [] args)throws IOException{
		FileReader fr = new FileReader("D:\\reverse_input.txt");
		FileWriter fw = new FileWriter("D:\\reverse_output.txt");
		BufferedReader janus = new BufferedReader(fr);

		String data;
		String reverse;
		while ((data = janus.readLine()) != null){
			String[] words = data.split(" ");
			for(String a: words){
				StringBuilder builder=new StringBuilder(a);
				System.out.print(builder.reverse().toString());
				fw.write(builder.reverse().toString());
			}
		}
	}
}