public class PersonDetails2_1 {
	public static void main(String[] args) {
		String firstName = "Gagandeep";
		String lastName = "Singh";
		int age =20 ;
		char gender = 'M';
		float weight = 65.2f;

		System.out.println("Person Details:");
		System.out.println("-------------");

		System.out.println("First Name: " + firstName);
		System.out.println("Last Name: " + lastName);
		System.out.println("Gender: " + gender);
		System.out.println("Age: " + age);
		System.out.println("First Name: " + weight);
	}
}