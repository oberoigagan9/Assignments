import java.util.Scanner;

public class PersonGenderMain {
	public static void main(String[] args) {		
		Gender gen;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Gender");
		int offset = sc.nextInt();
		switch(offset) {
		case 1:
			gen = Gender.M;
			break;
		case 2:
			gen = Gender.F;
			break;
		default:
			gen = Gender.O;
		}
		PersonGender gagan = new PersonGender("Gagandeep", "Singh", gen);
		gagan.setPhoneNo("9671798184");
		gagan.personDetails();
		sc.close();
	}
}