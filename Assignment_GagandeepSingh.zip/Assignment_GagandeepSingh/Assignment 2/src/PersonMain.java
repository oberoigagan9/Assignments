public class PersonMain {
	public static void main(String[] args) {
		Person2_3 gagan = new Person2_3("Gagandeep", "Singh", 'M');
		gagan.setPhoneNo("9671798184");
		gagan.personDetails();
	}
}