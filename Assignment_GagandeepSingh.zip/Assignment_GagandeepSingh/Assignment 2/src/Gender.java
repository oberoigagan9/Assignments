public enum Gender {
	M, F, O;
}