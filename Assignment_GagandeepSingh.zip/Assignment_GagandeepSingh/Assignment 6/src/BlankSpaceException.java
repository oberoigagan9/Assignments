public class BlankSpaceException extends Exception{
	public BlankSpaceException() {
		super();
	}
	public BlankSpaceException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public BlankSpaceException(String message, Throwable cause) {
		super(message, cause);
	}
	public BlankSpaceException(String message) {
		super(message);
	}

	public BlankSpaceException(Throwable cause) {
		super(cause);
	}
}