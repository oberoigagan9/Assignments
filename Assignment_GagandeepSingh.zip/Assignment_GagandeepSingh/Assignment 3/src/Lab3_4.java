import java.time.LocalDate;
import java.time.Period;
public class Lab3_4 {
		public void durationDate(){
			LocalDate birthdate = LocalDate.of(1998, 04, 05);
			LocalDate localdate = LocalDate.of(2015,07,22);

			Period diff = Period.between(birthdate, localdate);

			System.out.println(diff.getYears()+"years,"+ diff.getMonths()
					+ "months,and " + diff.getDays()+"days");
		}
	public static void main(String args[]){
		Lab3_4 obj=new Lab3_4();
		obj.durationDate();
	}	
}
