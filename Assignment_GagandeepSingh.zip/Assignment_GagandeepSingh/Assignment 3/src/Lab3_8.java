//import java.util.Collection;
import java.util.Scanner;
public class Lab3_8 {
	public void sortString(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of elements in String array: ");
		int num=sc.nextInt();
		String s1[]=new String[num];
		//ArrayList<String> a1=new ArrayList<String>();
		for(int i=0;i<num;i++){
			s1[i]=sc.next();
		}
		String temp = "";
		for(int i=0;i<num;i++){
			for(int j=i+1;j<num;j++){
				if(s1[i].compareTo(s1[j])>0){
					temp=s1[i];
					s1[i]=s1[j];
					s1[j]=temp;
				}
			}
		}
		int low = 0;
		int high = num-1;
		int mid = (low+high)/2;
		if(num % 2 == 0){
			for(int j=low;j<=mid;j++){
				s1[j]=s1[j].toUpperCase();
				System.out.println(s1[j]);
			}
			for(int k=mid+1;k<=high;k++){
				s1[k]=s1[k].toLowerCase();
				System.out.println(s1[k]);
			}
		}
		else{
			for(int j=low;j<=mid;j++){
				s1[j]=s1[j].toUpperCase();
				System.out.print(s1[j]+"  ");
			}
			for(int k=mid+1;k<=high;k++){
				s1[k]=s1[k].toLowerCase();
				System.out.println(s1[k]+"  ");
			}
		}
		sc.close();
	}
	public static void main(String args[]){
		 Lab3_8 obj=new Lab3_8();
		 obj.sortString();
	}
}